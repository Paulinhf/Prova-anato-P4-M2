import { readFileSync } from "node:fs";
const qs = JSON.parse(readFileSync(new URL("../data/questions.json", import.meta.url), "utf8"));
const ids = new Set(); let bad = 0;
for (const q of qs) {
  const e = (m) => { console.error(`✗ ${q.id}: ${m}`); bad++; };
  if (ids.has(q.id)) e("id duplicado"); ids.add(q.id);
  const oi = (q.options ?? []).map((o) => o.id);
  if (oi.length < 4 || oi.length > 5 || new Set(oi).size !== oi.length) e("exige 4 ou 5 alternativas distintas");
  if (!oi.includes(q.correctAnswer)) e("gabarito inválido");
  for (const k of ["exam", "topic", "subtopic", "difficulty", "question", "sourceMaterial", "reviewed"]) if (!q[k]) e(`campo ausente: ${k}`);
  if (q.explanations) for (const i of oi) if (!q.explanations[i]?.trim()) e(`sem explicação para ${i}`);
  if (q.exam === "Elaborada" && (oi.length !== 5 || !q.explanations || !q.references?.length)) e("questão elaborada exige 5 alternativas, explicações e referências");
  for (const s of [...(q.images ?? []), ...(q.noteImages ?? [])]) { try { readFileSync(new URL(`../public${s}`, import.meta.url)); } catch { e(`imagem ausente: ${s}`); } }
}
if (bad) process.exit(1);
console.log(`✓ ${qs.length} questões válidas`);
