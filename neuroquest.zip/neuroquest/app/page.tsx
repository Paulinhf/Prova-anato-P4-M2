import NeuroQuest from "@/components/NeuroQuest";
export default function Page() { return <NeuroQuest />; }
