import "./globals.css";
import type { Metadata } from "next";
export const metadata: Metadata = { title: "NeuroQuest — Telencéfalo e Diencéfalo", description: "Banco de questões de Neuroanatomia para Medicina" };
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return <html lang="pt-BR"><body>{children}</body></html>;
}
