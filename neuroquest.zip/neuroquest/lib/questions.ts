import raw from "@/data/questions.json";
export type Opt = { id: string; text: string };
export type Q = {
  id: string; topic: string; subtopic: string; difficulty: string; question: string;
  options: Opt[]; correctAnswer: string; explanations?: Record<string, string>;
  exam: string; officialNote?: string; images?: string[]; noteImages?: string[]; annulled?: boolean;
  learningObjective: string; references: string[]; sourceMaterial: string; reviewed: string;
};
export const questions = raw as unknown as Q[];
