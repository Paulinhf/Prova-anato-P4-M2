"use client";
import { useEffect, useState } from "react";
import { questions as ALL, type Q } from "@/lib/questions";

type Att = { id: string; pick: string; ok: boolean; t: number };
type Store = { att: Att[]; fav: string[]; rev: string[] };
type F = { topic: string; diff: string; status: string; sub: string; exam: string };

const KEY = "neuroquest:v1", L = "ABCDE";
const EMPTY: Store = { att: [], fav: [], rev: [] };
const shuffle = <T,>(a: T[]) => { const b = [...a]; for (let i = b.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [b[i], b[j]] = [b[j], b[i]]; } return b; };
const pct = (a: number, b: number) => (b ? Math.round((a * 100) / b) : 0);
const uniq = (a: string[]) => [...new Set(a)];
const btn = "rounded-lg bg-blue-950 px-4 py-2 text-white hover:bg-blue-900 disabled:opacity-40 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-700";
const alt = "rounded-lg border border-slate-300 bg-white px-4 py-2 hover:border-blue-950 disabled:opacity-40 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-700";

const Sel = ({ v, set, o, ph }: { v: string; set: (s: string) => void; o: [string, string][]; ph: string }) => (
  <select aria-label={ph} value={v} onChange={(e) => set(e.target.value)} className="rounded-lg border border-slate-300 bg-white p-2 text-sm">
    <option value="">{ph}</option>
    {o.map(([k, l]) => <option key={k} value={k}>{l}</option>)}
  </select>
);

const Bar = ({ l, n, ok }: { l: string; n: number; ok: number }) => (
  <div>
    <div className="flex justify-between text-sm"><span>{l}</span><span>{n ? `${ok}/${n} (${pct(ok, n)}%)` : "sem respostas"}</span></div>
    <div className="h-2 rounded bg-slate-200"><div className="h-2 rounded bg-emerald-700" style={{ width: `${pct(ok, n)}%` }} /></div>
  </div>
);

function Question({ q, pick, reveal, onPick }: { q: Q; pick?: string; reveal: boolean; onPick: (id: string) => void }) {
  return (
    <div>
      <p className="whitespace-pre-line text-lg leading-relaxed">{q.question}</p>
      {q.images?.map((s) => <img key={s} src={s} alt="Imagem da questão" className="mt-3 max-h-[28rem] w-full rounded border border-slate-200 bg-white object-contain" />)}
      <div role="radiogroup" aria-label="Alternativas" className="mt-4 space-y-2">
        {q.options.map((o, k) => {
          const ok = o.id === q.correctAnswer, sel = o.id === pick;
          const cls = reveal ? (ok ? "border-emerald-700 bg-emerald-50" : sel ? "border-red-700 bg-red-50" : "border-slate-200") : sel ? "border-blue-950 bg-blue-50" : "border-slate-300 hover:border-blue-950";
          return (
            <button key={o.id} role="radio" aria-checked={sel} disabled={reveal} onClick={() => onPick(o.id)}
              className={`flex w-full gap-3 rounded-lg border-2 p-3 text-left focus-visible:outline-2 focus-visible:outline-blue-700 ${cls}`}>
              <b>{L[k]}</b><span>{o.text}</span>
            </button>
          );
        })}
      </div>
      {reveal && (
        <section className="mt-5 space-y-2" aria-live="polite">
          <h3 className="font-semibold">{pick === q.correctAnswer ? "Você acertou." : pick ? "Você errou." : "Sem resposta."} Gabarito: {L[q.options.findIndex((o) => o.id === q.correctAnswer)]}</h3>
          {q.explanations && q.options.map((o, k) => (
            <div key={o.id} className={`rounded-lg border-l-4 p-3 text-sm ${o.id === q.correctAnswer ? "border-emerald-700 bg-emerald-50" : "border-slate-300 bg-slate-50"}`}>
              <b>Alternativa {L[k]} — {o.id === q.correctAnswer ? "Correta" : "Incorreta"}.</b> {q.explanations?.[o.id]}
            </div>
          ))}
          {!q.explanations && <p className="rounded-lg bg-slate-100 p-3 text-sm">Questão importada da prova: vale o gabarito oficial. A explicação individual das alternativas ainda não foi elaborada.{q.annulled && " Questão anulada no gabarito oficial; a alternativa marcada é a que corresponde aos itens apresentados."}</p>}
          {q.officialNote && <p className="whitespace-pre-line rounded-lg border-l-4 border-blue-950 bg-blue-50 p-3 text-sm"><b>Comentário do gabarito oficial:</b> {q.officialNote}</p>}
          {q.noteImages?.map((s) => <img key={s} src={s} alt="Imagem do comentário" className="max-h-96 w-full rounded border object-contain bg-white" />)}
          <p className="text-xs leading-relaxed text-slate-600">
            {q.learningObjective && <><b>Objetivo:</b> {q.learningObjective}<br /></>}
            <b>Fonte no material:</b> {q.sourceMaterial}<br />
            {q.references.length > 0 && <><b>Referências:</b> {q.references.join("; ")}<br /></>}
            <b>Revisão científica:</b> {q.reviewed}
          </p>
        </section>
      )}
    </div>
  );
}

export default function NeuroQuest() {
  const [st, setSt] = useState<Store | null>(null);
  const [v, setV] = useState<"home" | "study" | "exam">("home");
  const [list, setList] = useState<Q[]>([]);
  const [i, setI] = useState(0);
  const [picks, setPicks] = useState<Record<string, string>>({});
  const [conf, setConf] = useState<Record<string, boolean>>({});
  const [fin, setFin] = useState(false);
  const [f, setF] = useState<F>({ topic: "", diff: "", status: "", sub: "", exam: "" });
  const [n, setN] = useState(10);

  useEffect(() => { try { const s = localStorage.getItem(KEY); setSt(s ? JSON.parse(s) : EMPTY); } catch { setSt(EMPTY); } }, []);
  useEffect(() => { if (st) try { localStorage.setItem(KEY, JSON.stringify(st)); } catch { /* armazenamento indisponível */ } }, [st]);
  if (!st) return <p className="p-8">Carregando…</p>;

  const last = new Map<string, Att>();
  st.att.forEach((a) => last.set(a.id, a));
  const done = [...last.values()];
  const okN = done.filter((a) => a.ok).length;
  const wrong = new Set(st.att.filter((a) => !a.ok).map((a) => a.id));
  const filt = (ff: F) => ALL.filter((q) =>
    (!ff.exam || q.exam === ff.exam) && (!ff.topic || q.topic === ff.topic) && (!ff.diff || q.difficulty === ff.diff) && (!ff.sub || q.subtopic === ff.sub) &&
    (!ff.status || (ff.status === "new" ? !last.has(q.id) : ff.status === "wrong" ? wrong.has(q.id) : ff.status === "fav" ? st.fav.includes(q.id) : st.rev.includes(q.id))));
  const go = (mode: "study" | "exam", qs: Q[]) => {
    if (!qs.length) return alert("Nenhuma questão com esses filtros.");
    setList(qs.map((q) => ({ ...q, options: q.exam === "Elaborada" ? shuffle(q.options) : q.options })));
    setI(0); setPicks({}); setConf({}); setFin(false); setV(mode);
  };
  const rec = (qs: Q[]) => setSt((s) => s && { ...s, att: [...s.att, ...qs.filter((q) => picks[q.id]).map((q) => ({ id: q.id, pick: picks[q.id], ok: picks[q.id] === q.correctAnswer, t: Date.now() }))] });
  const flag = (k: "fav" | "rev", id: string) => setSt((s) => s && { ...s, [k]: s[k].includes(id) ? s[k].filter((x) => x !== id) : [...s[k], id] });
  const by = (key: "topic" | "difficulty") => uniq(ALL.map((q) => q[key])).map((k) => {
    const a = done.filter((x) => ALL.find((q) => q.id === x.id)?.[key] === k);
    return { k, n: a.length, ok: a.filter((x) => x.ok).length };
  });

  const q = list[i];
  const reveal = q ? (v === "study" ? !!conf[q.id] : fin) : false;
  const score = list.filter((x) => picks[x.id] === x.correctAnswer).length;
  const opt = (a: string[]) => a.map((x) => [x, x] as [string, string]);

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900">
      <header className="bg-blue-950 text-white">
        <div className="mx-auto flex max-w-3xl items-center justify-between gap-3 px-4 py-4">
          <h1 className="text-lg font-semibold sm:text-xl">NeuroQuest — Telencéfalo e Diencéfalo</h1>
          {v !== "home" && <button onClick={() => setV("home")} className="rounded border border-blue-300 px-3 py-1 text-sm">Início</button>}
        </div>
      </header>
      <main className="mx-auto max-w-3xl space-y-5 p-4">
        {v === "home" ? (
          <>
            <section className="grid grid-cols-2 gap-3 sm:grid-cols-4" aria-label="Estatísticas">
              {([["Questões", ALL.length], ["Respondidas", done.length], ["Aproveitamento", `${pct(okN, done.length)}%`], ["Tentativas", st.att.length]] as [string, string | number][]).map(([a, b]) => (
                <div key={a} className="rounded-lg bg-white p-3 shadow-sm"><div className="text-2xl font-bold text-blue-950">{b}</div><div className="text-xs text-slate-600">{a}</div></div>
              ))}
            </section>
            <section className="space-y-3 rounded-lg bg-white p-4 shadow-sm">
              <h2 className="font-semibold">Estudar</h2>
              <div className="flex flex-wrap gap-2">
                <Sel v={f.topic} set={(topic) => setF({ ...f, topic })} o={opt(uniq(ALL.map((q) => q.topic)))} ph="Todos os assuntos" />
                <Sel v={f.sub} set={(sub) => setF({ ...f, sub })} o={opt(uniq(ALL.map((q) => q.subtopic)))} ph="Todos os subassuntos" />
                <Sel v={f.diff} set={(diff) => setF({ ...f, diff })} o={opt(uniq(ALL.map((q) => q.difficulty)))} ph="Toda dificuldade" />
                <Sel v={f.exam} set={(exam) => setF({ ...f, exam })} o={opt(uniq(ALL.map((q) => q.exam)))} ph="Todas as provas" />
                <Sel v={f.status} set={(status) => setF({ ...f, status })} o={[["new", "Não respondidas"], ["wrong", "Erradas"], ["fav", "Favoritas"], ["rev", "Para revisar"]]} ph="Todas" />
              </div>
              <div className="flex flex-wrap gap-2">
                <button className={btn} onClick={() => go("study", filt(f))}>Modo de estudo ({filt(f).length})</button>
                <button className={alt} onClick={() => go("study", filt({ ...f, status: "wrong" }))}>Revisar erradas ({wrong.size})</button>
              </div>
            </section>
            <section className="space-y-3 rounded-lg bg-white p-4 shadow-sm">
              <h2 className="font-semibold">Simulado</h2>
              <p className="text-sm text-slate-600">Usa os filtros de assunto e dificuldade acima. O gabarito só aparece ao finalizar.</p>
              <div className="flex flex-wrap items-center gap-2">
                <label className="text-sm">Questões: <input type="number" min={1} max={ALL.length} value={n} onChange={(e) => setN(Math.max(1, +e.target.value || 1))} className="w-20 rounded border border-slate-300 p-1" /></label>
                <button className={btn} onClick={() => go("exam", shuffle(filt({ ...f, status: "" })).slice(0, n))}>Iniciar simulado</button>
              </div>
            </section>
            <section className="space-y-3 rounded-lg bg-white p-4 shadow-sm">
              <h2 className="font-semibold">Desempenho (última tentativa de cada questão)</h2>
              {[...by("topic"), ...by("difficulty")].map((b) => <Bar key={b.k} l={b.k} n={b.n} ok={b.ok} />)}
              <p className="text-xs text-slate-500">Dados salvos apenas neste navegador (localStorage); não há conta nem banco de dados em nuvem.</p>
            </section>
          </>
        ) : q && (
          <>
            <div className="h-2 rounded bg-slate-200" role="progressbar" aria-valuenow={i + 1} aria-valuemin={1} aria-valuemax={list.length}>
              <div className="h-2 rounded bg-blue-950" style={{ width: `${((i + 1) * 100) / list.length}%` }} />
            </div>
            <div className="flex flex-wrap items-center justify-between gap-2 text-sm text-slate-600">
              <span>Questão {i + 1} de {list.length} · {q.topic} · {q.subtopic} · {q.difficulty}</span>
              <span className="flex gap-2">
                <button aria-pressed={st.fav.includes(q.id)} onClick={() => flag("fav", q.id)} className="rounded border border-slate-300 bg-white px-2 py-1">{st.fav.includes(q.id) ? "★" : "☆"} Favorita</button>
                <button aria-pressed={st.rev.includes(q.id)} onClick={() => flag("rev", q.id)} className="rounded border border-slate-300 bg-white px-2 py-1">{st.rev.includes(q.id) ? "✔" : "＋"} Revisar depois</button>
              </span>
            </div>
            {v === "exam" && fin && <div className="rounded-lg bg-blue-950 p-4 text-white">Resultado: {score} de {list.length} ({pct(score, list.length)}%). Navegue pelas questões para ver as explicações.</div>}
            <article className="rounded-lg bg-white p-4 shadow-sm">
              <Question key={q.id} q={q} pick={picks[q.id]} reveal={reveal} onPick={(id) => setPicks((p) => ({ ...p, [q.id]: id }))} />
            </article>
            <nav className="flex items-center justify-between gap-2">
              <button className={alt} disabled={i === 0} onClick={() => setI(i - 1)}>Anterior</button>
              {v === "study" && !reveal && <button className={btn} disabled={!picks[q.id]} onClick={() => { rec([q]); setConf({ ...conf, [q.id]: true }); }}>Confirmar resposta</button>}
              {v === "exam" && !fin && <button className={btn} onClick={() => { rec(list); setFin(true); }}>Finalizar simulado</button>}
              <button className={alt} disabled={i === list.length - 1} onClick={() => setI(i + 1)}>Próxima</button>
            </nav>
          </>
        )}
      </main>
    </div>
  );
}
